﻿document.addEventListener("DOMContentLoaded", () => {

    /* =========================================================
       NAVIGATION
    ========================================================= */

    const navLinks =
        document.querySelectorAll(".sd-nav-link");

    const sections =
        document.querySelectorAll(".sd-content-section");

    const pageTitle =
        document.getElementById("pageTitle");

    const sidebar =
        document.getElementById("sidebar");

    const sidebarOverlay =
        document.getElementById("sidebarOverlay");

    const menuButton =
        document.getElementById("menuButton");

    const sidebarClose =
        document.getElementById("sidebarClose");


    const titles = {
        overview: "Vendor Overview",
        requests: "Incoming Requests",
        quotes: "Submitted Quotes",
        history: "Quote History"
    };


    function openSection(sectionId) {

        sections.forEach(section => {
            section.classList.toggle(
                "active",
                section.id === sectionId
            );
        });

        navLinks.forEach(link => {
            link.classList.toggle(
                "active",
                link.dataset.section === sectionId
            );
        });

        pageTitle.textContent =
            titles[sectionId] || "Vendor Portal";

        sidebar.classList.remove("open");
        sidebarOverlay.classList.remove("show");

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    }


    navLinks.forEach(link => {

        link.addEventListener("click", () => {
            openSection(link.dataset.section);
        });

    });


    document
        .querySelectorAll("[data-go-section]")
        .forEach(button => {

            button.addEventListener("click", () => {
                openSection(button.dataset.goSection);
            });

        });


    menuButton.addEventListener("click", () => {
        sidebar.classList.add("open");
        sidebarOverlay.classList.add("show");
    });


    sidebarClose.addEventListener("click", () => {
        sidebar.classList.remove("open");
        sidebarOverlay.classList.remove("show");
    });


    sidebarOverlay.addEventListener("click", () => {
        sidebar.classList.remove("open");
        sidebarOverlay.classList.remove("show");
    });



    /* =========================================================
       DEMO REQUEST DATA
    ========================================================= */

    const vendorRequests = [

        {
            id: "VR-4021",
            job: "JC-1052",
            vehicle: "Nissan X-Trail",
            year: "2019",
            vin: "JN1TANT32Z0014521",
            part: "Engine Mount",
            partNumber: "PT-ENG-001",
            specification: "Engine Mount · X-Trail T32",
            quantity: 1,
            urgency: "Urgent",
            status: "pending"
        },

        {
            id: "VR-4022",
            job: "JC-1048",
            vehicle: "Toyota Corolla",
            year: "2020",
            vin: "JTDBR32E202104882",
            part: "Headlamp Assembly",
            partNumber: "PT-BDY-007",
            specification: "Right Side Headlamp Assembly",
            quantity: 1,
            urgency: "Normal",
            status: "pending"
        },

        {
            id: "VR-4023",
            job: "JC-1050",
            vehicle: "Honda Vezel",
            year: "2021",
            vin: "RU312011452",
            part: "17-inch Alloy Wheel",
            partNumber: "PT-WHL-008",
            specification: "17 inch · 5x114.3",
            quantity: 2,
            urgency: "Normal",
            status: "pending"
        }

    ];


    const submittedQuotes = [

        {
            quoteId: "QT-5108",
            requestId: "VR-4018",
            part: "Front Brake Kit",
            price: 28500,
            delivery: "1 Day",
            warranty: "6 Months",
            stock: "In Stock",
            status: "Pending Review"
        }

    ];


    const quoteHistory = [

        {
            quoteId: "QT-5105",
            requestId: "VR-4012",
            part: "Car Battery",
            price: 32000,
            delivery: "Same Day",
            status: "Accepted"
        },

        {
            quoteId: "QT-5104",
            requestId: "VR-4010",
            part: "Shock Absorber",
            price: 41500,
            delivery: "2 Days",
            status: "Not Selected"
        },

        {
            quoteId: "QT-5101",
            requestId: "VR-4005",
            part: "Oil Filter Set",
            price: 9800,
            delivery: "1 Day",
            status: "Accepted"
        }

    ];



    /* =========================================================
       ESCAPE HELPER
    ========================================================= */

    function escapeHTML(value) {

        return String(value)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");

    }


    function formatCurrency(value) {

        return new Intl.NumberFormat(
            "en-LK",
            {
                style: "currency",
                currency: "LKR",
                maximumFractionDigits: 0
            }
        ).format(value);

    }



    /* =========================================================
       REQUEST RENDERING
    ========================================================= */

    const vendorRequestList =
        document.getElementById("vendorRequestList");


    function renderVendorRequests() {

        const pending =
            vendorRequests.filter(
                request => request.status === "pending"
            );


        if (!pending.length) {

            vendorRequestList.innerHTML = `

                <article class="sd-panel">
                    No pending vendor requests at the moment.
                </article>

            `;

            return;
        }


        vendorRequestList.innerHTML =
            pending.map(request => `

                <article class="sd-request-card">

                    <div class="sd-card-top">

                        <div>

                            <span class="sd-eyebrow">
                                ${escapeHTML(request.id)}
                            </span>

                            <h3>
                                ${escapeHTML(request.part)}
                            </h3>

                            <p>
                                Job Card #${escapeHTML(request.job)}
                            </p>

                        </div>

                        <span class="sd-badge ${
                            request.urgency === "Urgent"
                                ? "urgent"
                                : "normal"
                        }">
                            ${escapeHTML(request.urgency)}
                        </span>

                    </div>


                    <div class="sd-card-data">

                        <div class="sd-data-box">
                            <span>Vehicle</span>
                            <strong>
                                ${escapeHTML(request.vehicle)}
                            </strong>
                        </div>

                        <div class="sd-data-box">
                            <span>Year</span>
                            <strong>
                                ${escapeHTML(request.year)}
                            </strong>
                        </div>

                        <div class="sd-data-box">
                            <span>Part Number</span>
                            <strong>
                                ${escapeHTML(request.partNumber)}
                            </strong>
                        </div>

                        <div class="sd-data-box">
                            <span>Required Qty</span>
                            <strong>
                                ${escapeHTML(request.quantity)}
                            </strong>
                        </div>

                        <div class="sd-data-box">
                            <span>VIN</span>
                            <strong>
                                ${escapeHTML(request.vin)}
                            </strong>
                        </div>

                    </div>


                    <div class="sd-data-box" style="margin-top:12px;">
                        <span>Part Specification</span>

                        <strong>
                            ${escapeHTML(request.specification)}
                        </strong>
                    </div>


                    <div class="sd-card-actions">

                        <button
                            type="button"
                            class="sd-primary-btn"
                            data-have-part="${escapeHTML(request.id)}"
                        >
                            <i class="bi bi-check-circle"></i>
                            Have Part
                        </button>


                        <button
                            type="button"
                            class="sd-danger-btn"
                            data-no-part="${escapeHTML(request.id)}"
                        >
                            <i class="bi bi-x-circle"></i>
                            Do Not Have
                        </button>

                    </div>

                </article>

            `).join("");


        attachRequestEvents();

    }



    function attachRequestEvents() {

        document
            .querySelectorAll("[data-have-part]")
            .forEach(button => {

                button.addEventListener("click", () => {

                    openQuoteModal(
                        button.dataset.havePart
                    );

                });

            });


        document
            .querySelectorAll("[data-no-part]")
            .forEach(button => {

                button.addEventListener("click", () => {

                    const request =
                        vendorRequests.find(
                            item =>
                                item.id === button.dataset.noPart
                        );


                    if (!request) {
                        return;
                    }


                    request.status =
                        "not-available";


                    quoteHistory.unshift({

                        quoteId: "-",
                        requestId: request.id,
                        part: request.part,
                        price: 0,
                        delivery: "-",
                        status: "Part Not Available"

                    });


                    renderVendorRequests();
                    renderQuoteHistory();

                });

            });

    }



    /* =========================================================
       QUOTE MODAL
    ========================================================= */

    const quoteModal =
        document.getElementById("quoteModal");

    const quoteForm =
        document.getElementById("quoteForm");

    const quoteRequestId =
        document.getElementById("quoteRequestId");

    const quoteEditId =
        document.getElementById("quoteEditId");

    const quoteModalTitle =
        document.getElementById("quoteModalTitle");

    const quotePrice =
        document.getElementById("quotePrice");

    const quoteDelivery =
        document.getElementById("quoteDelivery");

    const quoteWarranty =
        document.getElementById("quoteWarranty");

    const quoteStock =
        document.getElementById("quoteStock");

    const quoteNote =
        document.getElementById("quoteNote");

    const quoteFormMessage =
        document.getElementById("quoteFormMessage");


    function openQuoteModal(requestId) {

        const request =
            vendorRequests.find(
                item => item.id === requestId
            );


        if (!request) {
            return;
        }


        quoteForm.reset();

        quoteEditId.value = "";

        quoteRequestId.value =
            request.id;

        quoteModalTitle.textContent =
            `${request.part} · ${request.id}`;

        quoteFormMessage.textContent = "";
        quoteFormMessage.className =
            "sd-form-message";

        quoteModal.hidden = false;

    }


    function openEditQuoteModal(quoteId) {

        const quote =
            submittedQuotes.find(
                item => item.quoteId === quoteId
            );


        if (
            !quote ||
            quote.status !== "Pending Review"
        ) {
            return;
        }


        quoteForm.reset();

        quoteEditId.value =
            quote.quoteId;

        quoteRequestId.value =
            quote.requestId;

        quoteModalTitle.textContent =
            `Edit ${quote.quoteId} · ${quote.part}`;

        quotePrice.value =
            quote.price;

        quoteDelivery.value =
            quote.delivery;

        quoteWarranty.value =
            quote.warranty;

        quoteStock.value =
            quote.stock;

        quoteNote.value =
            quote.note || "";

        quoteFormMessage.textContent = "";

        quoteFormMessage.className =
            "sd-form-message";

        quoteModal.hidden = false;

    }


    function closeQuoteModal() {

        quoteModal.hidden = true;

    }


    document
        .querySelectorAll("[data-close-modal]")
        .forEach(button => {

            button.addEventListener(
                "click",
                closeQuoteModal
            );

        });


    document.addEventListener(
        "keydown",
        event => {

            if (
                event.key === "Escape" &&
                !quoteModal.hidden
            ) {
                closeQuoteModal();
            }

        }
    );



    /* =========================================================
       SUBMIT QUOTE
    ========================================================= */

    quoteForm.addEventListener(
        "submit",
        event => {

            event.preventDefault();


            const request =
                vendorRequests.find(
                    item =>
                        item.id === quoteRequestId.value
                );


            const price =
                Number(quotePrice.value);


            if (
                !request ||
                !price ||
                !quoteDelivery.value ||
                !quoteWarranty.value ||
                !quoteStock.value
            ) {

                quoteFormMessage.textContent =
                    "Please complete all required quotation fields.";

                quoteFormMessage.className =
                    "sd-form-message error";

                return;
            }


            const editingQuoteId =
                quoteEditId.value.trim();


            if (editingQuoteId) {

                const existingQuote =
                    submittedQuotes.find(
                        item =>
                            item.quoteId === editingQuoteId
                    );


                if (
                    !existingQuote ||
                    existingQuote.status !== "Pending Review"
                ) {

                    quoteFormMessage.textContent =
                        "Only pending quotations can be edited.";

                    quoteFormMessage.className =
                        "sd-form-message error";

                    return;

                }


                existingQuote.price =
                    price;

                existingQuote.delivery =
                    quoteDelivery.value;

                existingQuote.warranty =
                    quoteWarranty.value;

                existingQuote.stock =
                    quoteStock.value;

                existingQuote.note =
                    quoteNote.value.trim();


                const historyItem =
                    quoteHistory.find(
                        item =>
                            item.quoteId === editingQuoteId
                    );


                if (historyItem) {

                    historyItem.price =
                        price;

                    historyItem.delivery =
                        quoteDelivery.value;

                }


                renderSubmittedQuotes();
                renderQuoteHistory();

                closeQuoteModal();

                openSection("quotes");

                return;

            }


            const quoteId =
                `QT-${5110 + submittedQuotes.length}`;


            submittedQuotes.unshift({

                quoteId: quoteId,
                requestId: request.id,
                part: request.part,
                price: price,
                delivery: quoteDelivery.value,
                warranty: quoteWarranty.value,
                stock: quoteStock.value,
                note: quoteNote.value.trim(),
                status: "Pending Review"

            });


            quoteHistory.unshift({

                quoteId: quoteId,
                requestId: request.id,
                part: request.part,
                price: price,
                delivery: quoteDelivery.value,
                status: "Pending Review"

            });


            request.status =
                "quoted";


            renderVendorRequests();
            renderSubmittedQuotes();
            renderQuoteHistory();


            closeQuoteModal();

            openSection("quotes");

        }
    );



    /* =========================================================
       SUBMITTED QUOTES
    ========================================================= */

    const submittedQuoteList =
        document.getElementById("submittedQuoteList");


    function renderSubmittedQuotes() {

        if (!submittedQuotes.length) {

            submittedQuoteList.innerHTML = `

                <article class="sd-panel">
                    No submitted quotations yet.
                </article>

            `;

            return;
        }


        submittedQuoteList.innerHTML =
            submittedQuotes.map(quote => `

                <article class="sd-quote-card">

                    <div class="sd-card-top">

                        <div>

                            <span class="sd-eyebrow">
                                ${escapeHTML(quote.quoteId)}
                            </span>

                            <h3>
                                ${escapeHTML(quote.part)}
                            </h3>

                            <p>
                                Request ${escapeHTML(quote.requestId)}
                            </p>

                        </div>

                        <span class="sd-badge submitted">
                            ${escapeHTML(quote.status)}
                        </span>

                    </div>


                    <div class="sd-card-data">

                        <div class="sd-data-box">
                            <span>Unit Price</span>
                            <strong>
                                ${escapeHTML(formatCurrency(quote.price))}
                            </strong>
                        </div>

                        <div class="sd-data-box">
                            <span>Delivery</span>
                            <strong>
                                ${escapeHTML(quote.delivery)}
                            </strong>
                        </div>

                        <div class="sd-data-box">
                            <span>Warranty</span>
                            <strong>
                                ${escapeHTML(quote.warranty)}
                            </strong>
                        </div>

                        <div class="sd-data-box">
                            <span>Availability</span>
                            <strong>
                                ${escapeHTML(quote.stock)}
                            </strong>
                        </div>

                        <div class="sd-data-box">
                            <span>Status</span>
                            <strong>
                                ${escapeHTML(quote.status)}
                            </strong>
                        </div>

                    </div>


                    ${
                        quote.status === "Pending Review"
                            ? `
                                <div class="sd-card-actions">

                                    <button
                                        type="button"
                                        class="sd-secondary-btn"
                                        data-edit-quote="${escapeHTML(quote.quoteId)}"
                                    >
                                        <i class="bi bi-pencil-square"></i>
                                        Edit Quote
                                    </button>

                                </div>
                            `
                            : ""
                    }

                </article>

            `).join("");


        document
            .querySelectorAll("[data-edit-quote]")
            .forEach(button => {

                button.addEventListener(
                    "click",
                    () => {

                        openEditQuoteModal(
                            button.dataset.editQuote
                        );

                    }
                );

            });

    }



    /* =========================================================
       QUOTE HISTORY
    ========================================================= */

    const quoteHistoryBody =
        document.getElementById("quoteHistoryBody");


    function getHistoryBadge(status) {

        if (status === "Accepted") {
            return "accepted";
        }

        if (
            status === "Not Selected" ||
            status === "Part Not Available"
        ) {
            return "rejected";
        }

        return "submitted";

    }


    function renderQuoteHistory() {

        quoteHistoryBody.innerHTML =
            quoteHistory.map(item => `

                <tr>

                    <td>
                        <strong>
                            ${escapeHTML(item.quoteId)}
                        </strong>
                    </td>

                    <td>
                        ${escapeHTML(item.requestId)}
                    </td>

                    <td>
                        ${escapeHTML(item.part)}
                    </td>

                    <td>
                        ${
                            item.price
                                ? escapeHTML(
                                    formatCurrency(item.price)
                                )
                                : "-"
                        }
                    </td>

                    <td>
                        ${escapeHTML(item.delivery)}
                    </td>

                    <td>
                        <span class="sd-badge ${getHistoryBadge(item.status)}">
                            ${escapeHTML(item.status)}
                        </span>
                    </td>

                </tr>

            `).join("");

    }



    /* =========================================================
       INITIAL RENDER
    ========================================================= */

    renderVendorRequests();
    renderSubmittedQuotes();
    renderQuoteHistory();

});

